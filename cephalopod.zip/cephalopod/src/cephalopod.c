#include <gtk/gtk.h>
#include <time.h>
#define ROJO 'R'
#define VERDE 'V'
#define VACIO 0
#define NADA 'N'
int tab[5][5];
char tab_color[5][5];
char jugador_color = NADA;
char jugador_actual = NADA;
int modo = 0;
int maquina = 0;


GtkBuilder *builder;

GObject *A5;
GObject *imagenA5;
GObject *B5;
GObject *imagenB5;
GObject *C5;
GObject *imagenC5;
GObject *D5;
GObject *imagenD5;
GObject *E5;
GObject *imagenE5;

GObject *A4;
GObject *imagenA4;
GObject *B4;
GObject *imagenB4;
GObject *C4;
GObject *imagenC4;
GObject *D4;
GObject *imagenD4;
GObject *E4;
GObject *imagenE4;

GObject *A3;
GObject *imagenA3;
GObject *B3;
GObject *imagenB3;
GObject *C3;
GObject *imagenC3;
GObject *D3;
GObject *imagenD3;
GObject *E3;
GObject *imagenE3;

GObject *A2;
GObject *imagenA2;
GObject *B2;
GObject *imagenB2;
GObject *C2;
GObject *imagenC2;
GObject *D2;
GObject *imagenD2;
GObject *E2;
GObject *imagenE2;

GObject *A1;
GObject *imagenA1;
GObject *B1;
GObject *imagenB1;
GObject *C1;
GObject *imagenC1;
GObject *D1;
GObject *imagenD1;
GObject *E1;
GObject *imagenE1;

GObject *principal;
GObject *reglas;
GObject *ventanareglas;
GObject *backmenu;

GObject *continuar;
GObject *ventananombre;
GObject *backmenu2;

GObject *continuar2;
GObject *tablero;

GObject *rendirse;
GObject *ventanarendirse;
GObject *norendirse;
GObject *sirendirse;

GObject *ventanasalir;
GObject *botonsalir1;
GObject *cancelarsalir;

GObject *gamemode1;

GObject *redcolor;
GObject *greencolor;
GObject *randomcolor;

GObject *redstart;
GObject *greenstart;
GObject *randomstart;


/*void asignarboton(){
	char cadena[8];
	for(int i = 0; i < 5 ; i++){
		for(int j= 0; j < 5; j++ ){
			sprintf(cadena, "%d,%d", i,j);
			boton[i][j] = GTK_WIDGET(gtk_builder_get_object(builder, cadena));
		}
	}
}*/
int casillas_vacias(){
	int cantidad = 0;
	for(int i=0; i < 5; i++){
		for(int j = 0; j < 5; j++){
			if(tab[i][j] == VACIO){
				cantidad++;
			}
		}
	}
	return cantidad;
}
void turno_maquina(char color){
	srand(time(NULL));
	int decision = (rand() % casillas_vacias())+1;
	int cuenta= 0;
	int pos_i = 0, pos_j = 0;
	for(int i=0; i < 5; i++){
		for(int j=0; j < 5; j++){
			if(tab[i][j] == VACIO){
				cuenta++;
				if(cuenta == decision){
					pos_i = i;
					pos_j = j;
					tab[i][j] = 1;
					tab_color[i][j] = color;
				}
			}
		}
	}
	//Llama una vez para saber la cantidad de opciones
}
void colocarimagenA5(){
	if (tab[0][0]!=VACIO){
		if (jugador_actual == ROJO){
			imagenA5 = gtk_image_new_from_file ("1red.png");
			gtk_button_set_image(GTK_BUTTON (A5), GTK_WIDGET(imagenA5));
			tab[0][0]=1;
			tab_color[0][0]= ROJO;
			turno_maquina(jugador_actual);
		}else{
			imagenA5 = gtk_image_new_from_file ("1green.png");
			gtk_button_set_image(GTK_BUTTON (A5), GTK_WIDGET(imagenA5));
			tab[0][0]=1;
			tab_color[0][0]= VERDE;
		}
	}

}
void colocarimagenB5(){

	if (jugador_actual == ROJO){
		imagenB5 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (B5), GTK_WIDGET(imagenB5));
	}else{
		imagenB5 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (B5), GTK_WIDGET(imagenB5));
	}

}
void colocarimagenC5(){
	if (jugador_actual == ROJO){
		imagenC5 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (C5), GTK_WIDGET(imagenC5));
	}else{
		imagenC5 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (C5), GTK_WIDGET(imagenC5));
	}

}
void colocarimagenD5(){
	if (jugador_actual == ROJO){
		imagenD5 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (D5), GTK_WIDGET(imagenD5));
	}else{
		imagenD5 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (D5), GTK_WIDGET(imagenD5));
	}

}
void colocarimagenE5(){
	if (jugador_actual == ROJO){
		imagenE5 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (E5), GTK_WIDGET(imagenE5));
	}else{
		imagenE5 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (E5), GTK_WIDGET(imagenE5));
	}

}

void colocarimagenA4(){
	if (jugador_actual == ROJO){
		imagenA4 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (A4), GTK_WIDGET(imagenA4));
	}else{
		imagenA4 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (A4), GTK_WIDGET(imagenA4));
	}

}
void colocarimagenB4(){
	if (jugador_actual == ROJO){
		imagenB4 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (B4), GTK_WIDGET(imagenB4));
	}else{
		imagenB4 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (B4), GTK_WIDGET(imagenB4));
	}

}
void colocarimagenC4(){
	if (jugador_actual == ROJO){
		imagenC4 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (C4), GTK_WIDGET(imagenC4));
	}else{
		imagenC4 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (C4), GTK_WIDGET(imagenC4));
	}

}
void colocarimagenD4(){
	if (jugador_actual == ROJO){
		imagenD4 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (D4), GTK_WIDGET(imagenD4));
	}else{
		imagenD4 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (D4), GTK_WIDGET(imagenD4));
	}

}
void colocarimagenE4(){
	if (jugador_actual == ROJO){
		imagenE4 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (E4), GTK_WIDGET(imagenE4));
	}else{
		imagenE4 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (E4), GTK_WIDGET(imagenE4));
	}

}

void colocarimagenA3(){
	if (jugador_actual == ROJO){
		imagenA3 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (A3), GTK_WIDGET(imagenA3));
	}else{
		imagenA3 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (A3), GTK_WIDGET(imagenA3));
	}

}
void colocarimagenB3(){
	if (jugador_actual == ROJO){
		imagenB3 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (B3), GTK_WIDGET(imagenB3));
	}else{
		imagenB3 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (B3), GTK_WIDGET(imagenB3));
	}

}
void colocarimagenC3(){
	if (jugador_actual == ROJO){
		imagenC3 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (C3), GTK_WIDGET(imagenC3));
	}else{
		imagenC3 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (C3), GTK_WIDGET(imagenC3));
	}

}
void colocarimagenD3(){
	if (jugador_actual == ROJO){
		imagenD3 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (D3), GTK_WIDGET(imagenD3));
	}else{
		imagenD3 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (D3), GTK_WIDGET(imagenD3));
	}

}
void colocarimagenE3(){
	if (jugador_actual == ROJO){
		imagenE3 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (E3), GTK_WIDGET(imagenE3));
	}else{
		imagenE3 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (E3), GTK_WIDGET(imagenE3));
	}

}

void colocarimagenA2(){
	if (jugador_actual == ROJO){
		imagenA2 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (A2), GTK_WIDGET(imagenA2));
	}else{
		imagenA2 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (A2), GTK_WIDGET(imagenA2));
	}

}
void colocarimagenB2(){
	if (jugador_actual == ROJO){
		imagenB2 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (B2), GTK_WIDGET(imagenB2));
	}else{
		imagenB2 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (B2), GTK_WIDGET(imagenB2));
	}

}
void colocarimagenC2(){
	if (jugador_actual == ROJO){
		imagenC2 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (C2), GTK_WIDGET(imagenC2));
	}else{
		imagenC2 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (C2), GTK_WIDGET(imagenC2));
	}

}
void colocarimagenD2(){
	if (jugador_actual == ROJO){
		imagenD2 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (D2), GTK_WIDGET(imagenD2));
	}else{
		imagenD2 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (D2), GTK_WIDGET(imagenD2));
	}

}
void colocarimagenE2(){
	if (jugador_actual == ROJO){
		imagenE2 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (E2), GTK_WIDGET(imagenE2));
	}else{
		imagenE2 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (E2), GTK_WIDGET(imagenE2));
	}

}

void colocarimagenA1(){
	if (jugador_actual == ROJO){
		imagenA1 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (A1), GTK_WIDGET(imagenA1));
	}else{
		imagenA1 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (A1), GTK_WIDGET(imagenA1));
	}

}
void colocarimagenB1(){
	if (jugador_actual == ROJO){
		imagenB1 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (B1), GTK_WIDGET(imagenB1));
	}else{
		imagenB1 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (B1), GTK_WIDGET(imagenB1));
	}

}
void colocarimagenC1(){
	if (jugador_actual == ROJO){
		imagenC1 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (C1), GTK_WIDGET(imagenC1));
	}else{
		imagenC1 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (C1), GTK_WIDGET(imagenC1));
	}

}
void colocarimagenD1(){
	if (jugador_actual == ROJO){
		imagenD1 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (D1), GTK_WIDGET(imagenD1));
	}else{
		imagenD1 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (D1), GTK_WIDGET(imagenD1));
	}

}
void colocarimagenE1(){
	if (jugador_actual == ROJO){
		imagenE1 = gtk_image_new_from_file ("1red.png");
		gtk_button_set_image(GTK_BUTTON (E1), GTK_WIDGET(imagenE1));
	}else{
		imagenE1 = gtk_image_new_from_file ("1green.png");
		gtk_button_set_image(GTK_BUTTON (E1), GTK_WIDGET(imagenE1));
	}

}

void mostrarocultar1(GObject *cosito, gpointer data){
	gtk_widget_hide(principal);
	gtk_widget_show_all(data);
}
void mostrarocultar11(GObject *cosito, gpointer data){
	gtk_widget_hide(data);
	gtk_widget_show_all(principal);
}
void mostrarocultar2(GObject *cosito, gpointer data){
	if (jugador_color != NADA && jugador_actual != NADA && modo != 0 ){
		gtk_widget_hide(principal);
		gtk_widget_show_all(data);
	}
}
void mostrarocultar22(GObject *cosito, gpointer data){
	gtk_widget_hide(data);
	gtk_widget_show_all(principal);
}
void mostrarocultar3(GObject *cosito, gpointer data){
	gtk_widget_hide(ventananombre);
	gtk_widget_show_all(data);
	while(casillas_vacias() != 0){
		/*
	            Elige donde colocar su dado
	            Captura si es posible
	            Se retornan los dados capturados a sus duenhos
		 */

		if(maquina == 1 && jugador_actual != jugador_color){
			//Si es jugador vs maquina y es el turno de la maquina;
			turno_maquina(jugador_actual);

		}else{

			g_signal_connect (A5, "clicked", G_CALLBACK (colocarimagenA5), NULL);
			g_signal_connect (B5, "clicked", G_CALLBACK (colocarimagenB5), NULL);
			g_signal_connect (C5, "clicked", G_CALLBACK (colocarimagenC5), NULL);
			g_signal_connect (D5, "clicked", G_CALLBACK (colocarimagenD5), NULL);
			g_signal_connect (E5, "clicked", G_CALLBACK (colocarimagenE5), NULL);

			g_signal_connect (A4, "clicked", G_CALLBACK (colocarimagenA4), NULL);
			g_signal_connect (B4, "clicked", G_CALLBACK (colocarimagenB4), NULL);
			g_signal_connect (C4, "clicked", G_CALLBACK (colocarimagenC4), NULL);
			g_signal_connect (D4, "clicked", G_CALLBACK (colocarimagenD4), NULL);
			g_signal_connect (E4, "clicked", G_CALLBACK (colocarimagenE4), NULL);

			g_signal_connect (A3, "clicked", G_CALLBACK (colocarimagenA3), NULL);
			g_signal_connect (B3, "clicked", G_CALLBACK (colocarimagenB3), NULL);
			g_signal_connect (C3, "clicked", G_CALLBACK (colocarimagenC3), NULL);
			g_signal_connect (D3, "clicked", G_CALLBACK (colocarimagenD3), NULL);
			g_signal_connect (E3, "clicked", G_CALLBACK (colocarimagenE3), NULL);

			g_signal_connect (A2, "clicked", G_CALLBACK (colocarimagenA2), NULL);
			g_signal_connect (B2, "clicked", G_CALLBACK (colocarimagenB2), NULL);
			g_signal_connect (C2, "clicked", G_CALLBACK (colocarimagenC2), NULL);
			g_signal_connect (D2, "clicked", G_CALLBACK (colocarimagenD2), NULL);
			g_signal_connect (E2, "clicked", G_CALLBACK (colocarimagenE2), NULL);

			g_signal_connect (A1, "clicked", G_CALLBACK (colocarimagenA1), NULL);
			g_signal_connect (B1, "clicked", G_CALLBACK (colocarimagenB1), NULL);
			g_signal_connect (C1, "clicked", G_CALLBACK (colocarimagenC1), NULL);
			g_signal_connect (D1, "clicked", G_CALLBACK (colocarimagenD1), NULL);
			g_signal_connect (E1, "clicked", G_CALLBACK (colocarimagenE1), NULL);


		}



		if(jugador_actual == ROJO){
			jugador_actual = VERDE;
		}else{
			jugador_actual = ROJO;
		}
	}
}
void mostrarocultar4(GObject *cosito, gpointer data){
	gtk_widget_hide(tablero);
	gtk_widget_show_all(data);

}
void mostrarocultar44(GObject *cosito, gpointer data){
	gtk_widget_hide(data);
	gtk_widget_show_all(tablero);
}
void mostrarocultar444(GObject *cosito, gpointer data){
	gtk_widget_hide(data);
	gtk_widget_show_all(principal);
}
void mostrarocultarventanasalir(GObject *cosito, gpointer data){
	gtk_widget_hide(data);
	gtk_widget_show_all(ventanasalir);
}
void mostrarocultarventanasalir1(GObject *cosito, gpointer data){
	gtk_widget_hide(ventanasalir);
	gtk_widget_show_all(principal);
}
void gamemode(){
	modo = 1;
	maquina = 1;
}

void elegircolor1(){
	jugador_color = ROJO;
}
void elegircolor2(){
	jugador_color = VERDE;
}
void elegircolorrandom(){
	srand(time(NULL));

	// Generar un número aleatorio entre 0 y 1
	int aleatorio = rand() % 2;

	// Elegir el color en base al número aleatorio
	if (aleatorio == 0) {
		jugador_color = ROJO;
	} else {
		jugador_color = VERDE;
	}
}

void empiezacolor1(){
	jugador_actual = ROJO;
}
void empiezacolor2(){
	jugador_actual = VERDE;
}
void empiezacolorrandom(){
	srand(time(NULL));

	// Generar un número aleatorio entre 0 y 1
	int aleatorio = rand() % 2;

	// Elegir el color en base al número aleatorio
	if (aleatorio == 0) {
		jugador_actual = ROJO;
	} else {
		jugador_actual = VERDE;
	}
}

int main (int argc, char *argv[])
{

	gtk_init (&argc, &argv);
	builder = gtk_builder_new_from_file("Cephalopod.glade");
	/* create the main, top level, window */
	principal = gtk_builder_get_object(builder, "principal");
	reglas = gtk_builder_get_object(builder, "reglas");
	ventanareglas = gtk_builder_get_object(builder, "ventanareglas");
	backmenu = gtk_builder_get_object(builder, "backmenu");

	continuar = gtk_builder_get_object(builder, "continuar");
	ventananombre = gtk_builder_get_object(builder, "ventananombre");
	backmenu2 = gtk_builder_get_object(builder, "backmenu2");
	/* give it the title */

	continuar2 = gtk_builder_get_object(builder, "continuar2");
	tablero = gtk_builder_get_object(builder, "tablero");

	rendirse = gtk_builder_get_object(builder, "rendirse");
	ventanarendirse = gtk_builder_get_object(builder, "ventanarendirse");
	norendirse = gtk_builder_get_object(builder, "norendirse");
	sirendirse = gtk_builder_get_object(builder, "sirendirse");

	ventanasalir = gtk_builder_get_object(builder, "ventanasalir");
	botonsalir1 = gtk_builder_get_object(builder, "botonsalir1");
	cancelarsalir = gtk_builder_get_object(builder, "cancelarsalir");

	gamemode1 = gtk_builder_get_object(builder, "gamemode1");

	redcolor = gtk_builder_get_object(builder, "redcolor");
	greencolor = gtk_builder_get_object(builder, "greencolor");
	randomcolor = gtk_builder_get_object(builder, "randomcolor");

	redstart = gtk_builder_get_object(builder, "redstart");
	greenstart = gtk_builder_get_object(builder, "greenstart");
	randomstart = gtk_builder_get_object(builder, "randomstart");

	A5 = gtk_builder_get_object(builder, "A5");
	B5 = gtk_builder_get_object(builder, "B5");
	C5 = gtk_builder_get_object(builder, "C5");
	D5 = gtk_builder_get_object(builder, "D5");
	E5 = gtk_builder_get_object(builder, "E5");

	A4 = gtk_builder_get_object(builder, "A4");
	B4 = gtk_builder_get_object(builder, "B4");
	C4 = gtk_builder_get_object(builder, "C4");
	D4 = gtk_builder_get_object(builder, "D4");
	E4 = gtk_builder_get_object(builder, "E4");

	A3 = gtk_builder_get_object(builder, "A3");
	B3 = gtk_builder_get_object(builder, "B3");
	C3 = gtk_builder_get_object(builder, "C3");
	D3 = gtk_builder_get_object(builder, "D3");
	E3 = gtk_builder_get_object(builder, "E3");

	A2 = gtk_builder_get_object(builder, "A2");
	B2 = gtk_builder_get_object(builder, "B2");
	C2 = gtk_builder_get_object(builder, "C2");
	D2 = gtk_builder_get_object(builder, "D2");
	E2 = gtk_builder_get_object(builder, "E2");

	A1 = gtk_builder_get_object(builder, "A1");
	B1 = gtk_builder_get_object(builder, "B1");
	C1 = gtk_builder_get_object(builder, "C1");
	D1 = gtk_builder_get_object(builder, "D1");
	E1 = gtk_builder_get_object(builder, "E1");

	/* Connect the destroy signal of the window to gtk_main_quit
	 * When the window is about to be destroyed we get a notification and
	 * stop the main GTK+ loop
	 */
	g_signal_connect (principal, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	g_signal_connect (reglas, "clicked", G_CALLBACK (mostrarocultar1), ventanareglas);
	g_signal_connect (backmenu, "clicked", G_CALLBACK (mostrarocultar11), ventanareglas);

	g_signal_connect (continuar, "clicked", G_CALLBACK (mostrarocultar2), ventananombre);
	g_signal_connect (backmenu2, "clicked", G_CALLBACK (mostrarocultar22), ventananombre);

	g_signal_connect (continuar2, "clicked", G_CALLBACK (mostrarocultar3), tablero);

	g_signal_connect (rendirse, "clicked", G_CALLBACK (mostrarocultar4), ventanarendirse);
	g_signal_connect (norendirse, "clicked", G_CALLBACK (mostrarocultar44), ventanarendirse);
	g_signal_connect (sirendirse, "clicked", G_CALLBACK (mostrarocultar444), ventanarendirse);

	g_signal_connect (botonsalir1, "clicked", G_CALLBACK (mostrarocultarventanasalir), principal);
	g_signal_connect (cancelarsalir, "clicked", G_CALLBACK (mostrarocultarventanasalir1), principal);

	g_signal_connect (gamemode1, "clicked", G_CALLBACK (gamemode), NULL);

	g_signal_connect (redcolor, "clicked", G_CALLBACK (elegircolor1), NULL);
	g_signal_connect (greencolor, "clicked", G_CALLBACK (elegircolor2), NULL);
	g_signal_connect (randomcolor, "clicked", G_CALLBACK (elegircolorrandom), NULL);

	g_signal_connect (redstart, "clicked", G_CALLBACK (empiezacolor1), NULL);
	g_signal_connect (greenstart, "clicked", G_CALLBACK (empiezacolor2), NULL);
	g_signal_connect (randomstart, "clicked", G_CALLBACK (empiezacolorrandom), NULL);

	//g_signal_connect (principal, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	/* Create the "Hello, World" label  */


	/* and insert it into the main window  */


	/* make sure that everything, window and label, are visible */
	gtk_widget_show_all(principal);

	/* start the main loop, and let it rest there until the application is closed */
	gtk_main ();

	return 0;
}

